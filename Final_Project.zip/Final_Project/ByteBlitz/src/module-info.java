/**
 * 
 */
/**
 * 
 */
module ByteBlitz {
}