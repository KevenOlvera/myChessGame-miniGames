package hangman;

import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Random;

public class BitBlitz
{
	final static String blackRook = "\033[30m\u2656\033[31;33m", blackKnight ="\033[30m\u2658\033[31;33m", blackBishop = "\033[30m\u2657\033[31;33m";
    final static String blackQueen = "\033[30m\u2655\033[31;33m", blackKing = "\033[30m\u2654\033[31;33m", blackPawn="\033[30m\u2659\033[31;33m";

    final static String whiteRook = "\033[37m\u2656\033[31;33m", whiteKnight = "\033[37m\u2658\033[31;33m", whiteBishop = "\033[37m\u2657\033[31;33m";
    final static String whiteQueen = "\033[37m\u2655\033[31;33m", whiteKing ="\033[37m\u2654\033[31;33m", whitePawn = "\033[37m\u2659\033[31;33m";
    
    final static String blackSquare = "\033[30m\u2B1B", whiteSquare = "\033[97m\u2B1B\u001B[38;5;214m";
	
    final static String ANSI_BLUE = "\033[34m";
	final static String ANSI_DEFAULT = "\033[38;5;214m", ANSI_GOLD = "\033[38;5;214m";
	final static String ANSI_GREEN = "\033[32m";
	final static String ANSI_RED = "\033[31m";

    public void printLogo()
    {
        final String ANSI_GOLD = "\033[38;5;214m";

        System.out.print(ANSI_GOLD+"\n" + //
        "______ _____ _____  ______ _     _____ _____ ______    _____  _   _  _____ _____ _____ \n" + //
        "| ___ \\_   _|_   _| | ___ \\ |   |_   _|_   _|___  /_  /  __ \\| | | ||  ___/  ___/  ___|\n" + //
        "| |_/ / | |   | |   | |_/ / |     | |   | |    / /(_) | /  \\/| |_| || |__ \\ `--.\\ `--. \n" + //
        "| ___ \\ | |   | |   | ___ \\ |     | |   | |   / /     | |    |  _  ||  __| `--. \\`--. \\\n" + //
        "| |_/ /_| |_  | |   | |_/ / |_____| |_  | | ./ /____  | \\__/\\| | | || |___/\\__/ /\\__/ /\n" + //
        "\\____/ \\___/  \\_/   \\____/\\_____/\\___/  \\_/ \\_____(_)  \\____/\\_| |_/\\____/\\____/\\____/ \n" + //
        "                                                                                       \n" + //
        "                                                                                       \n" + //
        "");
    }
    
    public void printWhiteBoard()
    {

        String blackRook = "\033[30m\u2656\033[31;33m", blackKnight ="\033[30m\u2658\033[31;33m", blackBishop = "\033[30m\u2657\033[31;33m";
        String blackQueen = "\033[30m\u2655\033[31;33m", blackKing = "\033[30m\u2654\033[31;33m", blackPawn="\033[30m\u2659\033[31;33m";

        String whiteRook = "\033[37m\u2656\033[31;33m", whiteKnight = "\033[37m\u2658\033[31;33m", whiteBishop = "\033[37m\u2657\033[31;33m";
        String whiteQueen = "\033[37m\u2655\033[31;33m", whiteKing ="\033[37m\u2654\033[31;33m", whitePawn = "\033[37m\u2659\033[31;33m";
        
        String blackSquare = "\u2B1B", whiteSquare = "\u001B[97m\u2B1B\u001B[38;5;214m";
        
        System.out.println("\t\t\t8 ["+blackRook+"]   ["+blackKnight+"]   ["+blackBishop+"]   ["+blackQueen+"]  ["+blackKing+"]  ["+blackBishop+"]  ["+blackKnight+"]  ["+blackRook+"]\n");
        System.out.println("\t\t\t7 ["+blackPawn+"]   ["+blackPawn+"]   ["+blackPawn+"]   ["+blackPawn+"]  ["+blackPawn+"]  ["+blackPawn+"]  ["+blackPawn+"]  ["+blackPawn+"]\n");
        
        System.out.println("\t\t\t6 ["+whiteSquare+"]  ["+blackSquare+"] [" +whiteSquare+"]  ["+blackSquare+"] ["+whiteSquare+"] ["+blackSquare+"] ["+whiteSquare+"] ["+blackSquare+"]\n");
        System.out.println("\t\t\t5 ["+blackSquare+"]  [" +whiteSquare+"] ["+blackSquare+"]  ["+whiteSquare+"] ["+blackSquare+"] ["+whiteSquare+"] ["+blackSquare+"] ["+whiteSquare+"]\n");
        System.out.println("\t\t\t4 ["+whiteSquare+"]  ["+blackSquare+"] [" +whiteSquare+"]  ["+blackSquare+"] ["+whiteSquare+"] ["+blackSquare+"] ["+whiteSquare+"] ["+blackSquare+"]\n");
        System.out.println("\t\t\t3 ["+blackSquare+"]  [" +whiteSquare+"] ["+blackSquare+"]  ["+whiteSquare+"] ["+blackSquare+"] ["+whiteSquare+"] ["+blackSquare+"] ["+whiteSquare+"]\n");

        System.out.println("\t\t\t2 ["+whitePawn+"]   ["+whitePawn+"]   ["+whitePawn+"]  ["+whitePawn+"]  ["+whitePawn+"]  ["+whitePawn+"]  ["+whitePawn+"]  ["+whitePawn+"]\n");
        System.out.println("\t\t\t1 ["+whiteRook+"]   ["+whiteKnight+"]   ["+whiteBishop+"]  ["+whiteQueen+"]  ["+whiteKing+"]  ["+whiteBishop+"]  ["+whiteKnight+"]  ["+whiteRook+"]\n");
        System.out.println("\t\t\t   a     b     c    d    e    f    g    h");
        
    }
    
    public void clearScreen()
    {

        System.out.print("\033[H\033[2J");
        System.out.flush();
        
    }

    public String chooseRandomSide()
    {
        System.out.println("\n\t\tRandomizing Player Color...\n");

        Random randomSide = new Random();
        boolean isWhite = randomSide.nextBoolean();

        return isWhite? "white": "black";
    }

    public void Tutorial(int playerTurn)
    {

        if(playerTurn<=2)
                    {
                        System.out.println("\t\tMove Piece:\n\t\tFormat:\tCurrent-Position, Next-Position");
                        System.out.println("\t\tRook: R, Knight: N, Bishop: B, King: K, Queen: Q");
                        System.out.println("\t\tExample Move [Rook a1 to a3]: a1 a3");
                        System.out.println("\t\tExample Move [Pawn e2 to e4]: e2 e4");
                        System.out.print("\t\t                              ");
                    }
    }

    public String[] lengthTwoStrings(String CurrentPosition, String NextPosition, Scanner sc, String playerOne, String playerTwo, int playerTurn)
    {
        final String ANSI_RED = "\033[31m";
        final String ANSI_DEFAULT = "\033[38;5;214m";
        
        String Positions[] = new String[2];

        int Wrong_Redo1=0;
        int Wrong_Redo2=0;
        
        if(playerTurn%2!=0)
        {
        	System.out.println(playerOne+"'s Turn "+whiteSquare);       	
        }

        else
        {
        	System.out.println(playerTwo+"'s Turn "+blackSquare);
        }
        
        do{
            if(CurrentPosition.length()>2)
            {
                Wrong_Redo1=1;
            }
            else
            {
                Wrong_Redo1=0;
            }

            if(Wrong_Redo1==0)
            {
                System.out.print("\n\t\tYour Piece: ");
                CurrentPosition = sc.next();
            }
            else
            {
                System.out.print(ANSI_RED+"\n\t\tYour Piece: ");
                CurrentPosition = sc.next();
                System.out.print(ANSI_DEFAULT);
            }
        }
        while(CurrentPosition.length()>2);

        System.out.println();//new line

        //NextPosition:
        do{
            if(NextPosition.length()>2)
            {
                Wrong_Redo2=1;
            }
            else
            {
                Wrong_Redo2=0;
            }

            if(Wrong_Redo2==0)
            {
                System.out.print("\n\t\tMove To: ");
                NextPosition = sc.next();
            }
            else
            {
                System.out.print(ANSI_RED+"\n\t\tMove To: ");
                NextPosition = sc.next();
                System.out.print(ANSI_DEFAULT);
            }
        }
        while(NextPosition.length()>2);

        Positions[0] = CurrentPosition;
        Positions[1] = NextPosition;

        System.out.println("Move: "+CurrentPosition+" "+NextPosition);

        return Positions;
    }

    public static boolean checkIfPlayerChoseTheirOwnPiece(int playerTurn, int CurrentPosition_DecodedNotation[], String CURRENTBOARD[][], String playerOne, String playerTwo)
    {
        boolean check = false;

        int row=CurrentPosition_DecodedNotation[0];
        int column=CurrentPosition_DecodedNotation[1];

        if(playerTurn%2!=0)
        {
            //if current player is playing the white side,
            //check whether they have selected a valid piece
            //if the switch accesses a case, they selected a valid piece to move
        	
        	System.out.println("\t\t\t"+whiteSquare+" "+playerOne+"'s Turn");
            switch(CURRENTBOARD[row][column])
            {
                case "\033[37m\u2656\033[31;33m":
                {
                    //Checking if white rook
                    check = true;
                    break;
                }
                case "\033[37m\u2658\033[31;33m":
                {
                    //checking if white knight
                    check = true;
                    break;
                }
                case "\033[37m\u2657\033[31;33m":
                {
                    //checking if white bishop
                    check = true;
                    break;
                }
                case "\033[37m\u2655\033[31;33m":
                {
                    //checking if white queen
                    check = true;
                    break;
                }
                case "\033[37m\u2654\033[31;33m":
                {
                    //checking if white king
                    check = true;
                    break;
                }
                case "\033[37m\u2659\033[31;33m":
                {
                    //checking if white pawn
                    check = true;
                    break;
                }
                default :
                {
                    //if they select a square that does not have one of their pieces on there
                    System.out.println("\t\t\u001B[31mThe selected square is not valid, please reselect\u001B[38;5;214m");
                    return check;
                }
            }
        }
        else
        {
            //if current player is playing the black side,
            //check whether they have selected a valid piece

            //if switch accesses a case, they have selected a valid piece to move
        	System.out.println("\t\t\t"+blackSquare+" "+playerTwo+"'s Turn");
            switch(CURRENTBOARD[row][column])
            {
                case "\033[30m\u2656\033[31;33m":
                {
                    //Checking if black rook
                    check = true;
                    break;
                }
                case "\033[30m\u2658\033[31;33m":
                {
                    //checking if black knight
                    check = true;
                    break;
                }
                case "\033[30m\u2657\033[31;33m":
                {
                    //checking if black bishop
                    check = true;
                    break;
                }
                case "\033[30m\u2655\033[31;33m":
                {
                    //checking if black queen
                    check = true;
                    break;
                }
                case "\033[30m\u2654\033[31;33m":
                {
                    //checking if black king
                    check = true;
                    break;
                }
                case "\033[30m\u2659\033[31;33m":
                {
                    //checking if black pawn
                    check = true;
                    break;
                }
                default:
                {
                    System.out.println("\t\t\033[31mThe selected square is not valid, please reselect\033[38;5;214m");
                    return check;
                }
            }
        }

        return check;
    }

    public static int DecodeRow(String Position)
    {
    	int row;
    	char userRow = Position.charAt(1);
    	
    	if(userRow=='1') {
    		row = 7;
    	}
    	else if(userRow=='2')
    	{
    		row = 6;
    	}
    	else if(userRow=='3')
    	{
    		row = 5;
    	}
    	else if(userRow=='4')
    	{
    		row = 4;
    	}
    	else if(userRow=='5')
    	{
    		row = 3;
    	}
    	else if(userRow=='6')
    	{
    		row = 2;
    	}
    	else if(userRow=='7')
    	{
    		row = 1;
    	}
    	else if(userRow=='8')
    	{
    		row = 0;
    	}
    	else
    	{
    		System.out.println("Please Enter a Valid Row");
    		row = 0;
    	}
    	return row;
    }
    
    public static int DecodeColumn(String Position)
    {
    	int column;
    	char userColumn = Position.charAt(0);
    	
    	if(userColumn=='a')
    	{
    		column = 0;
    	}
    	else if(userColumn=='b')
    	{
    		column = 1;
    	}
    	else if(userColumn=='c')
    	{
    		column = 2;
    	}
    	else if(userColumn=='d')
    	{
    		column = 3;
    	}
    	else if(userColumn=='e')
    	{
    		column = 4;
    	}
    	else if(userColumn=='f')
    	{
    		column = 5;
    	}
    	else if(userColumn=='g')
    	{
    		column = 6;
    	}
    	else if(userColumn=='h')
    	{
    		column = 7;
    	}
    	else
    	{
    		System.out.println("Please Enter a Valid Row");
    		column = 0;
    	}
    	
    	return column;
    }

    public static boolean rookCheck(String CURRENTBOARD[][], int CurrentPosition[], int NextPosition[])
    {
    	
    	return true;
    }
    
    public static boolean knightCheck(String CURRENTBOARD[][], int CurrentPosition[], int NextPosition[])
    {
    	boolean knightBool = false;
    	
    	//Two up, one left/right
    	if((2+CurrentPosition[0]==NextPosition[0]) && ((1+CurrentPosition[1])==NextPosition[1]))
    	{
    		return true;
    	}
    	else if((2+CurrentPosition[0]==NextPosition[0]) && ((CurrentPosition[1]-1)==NextPosition[1]))
    	{
    		return true;
    	}//One up, Two left/right
    	else if((1+CurrentPosition[0]==NextPosition[0]) && ((CurrentPosition[1]+2)==NextPosition[1]))
    	{
    		return true;
    	}
    	else if((1+CurrentPosition[0]==NextPosition[0]) && ((CurrentPosition[1]-2)==NextPosition[1]))
    	{
    		return true;
    	}//One down, Two left/right
    	else if(((CurrentPosition[0]-1)==NextPosition[0]) && ((CurrentPosition[1]+2)==NextPosition[1]))
    	{
    		return true;
    	}
    	else if(((CurrentPosition[0]-1)==NextPosition[0]) && ((CurrentPosition[1]-2)==NextPosition[1]))
    	{
    		return true;
    	}
    	if(((CurrentPosition[0]-2)==NextPosition[0]) && ((1+CurrentPosition[1])==NextPosition[1]))
    	{
    		return true;
    	}
    	else if(((CurrentPosition[0]-2)==NextPosition[0]) && ((CurrentPosition[1]-1)==NextPosition[1]))
    	{
    		return true;
    	}
    	
    	return knightBool;
    }
    
    public static boolean pawnCheck(String CURRENTBOARD[][], int CurrentPosition[], int NextPosition[], int playerTurn, String History[][])
    {
    	
    	int promoteOption;
    	
    	if(playerTurn%2!=0)
    	{
    		//white
    		//push forward 2:
			if(CurrentPosition[0]==6&&NextPosition[0]==4&&unoccupied(CURRENTBOARD, NextPosition[0], NextPosition[1])&&CurrentPosition[1]==NextPosition[1])
			{
				//checks push of two from pawn start
				return true;
			}
			else if(NextPosition[0]==(CurrentPosition[0]-1)&&unoccupied(CURRENTBOARD, NextPosition[0], NextPosition[1])&&CurrentPosition[1]==NextPosition[1])
			{
				//single push
				return true;
			}
			else if(NextPosition[0]==(CurrentPosition[0]-1)&&NextPosition[1]==(CurrentPosition[1]+1))
			{
				//for taking pieces
				return true;
			}
			else if(NextPosition[0]==(CurrentPosition[0]-1)&&NextPosition[1]==(CurrentPosition[1]-1))
			{
				//for taking pieces
				return true;
			}
			else if(NextPosition[0]==0)
			{
				do {
					System.out.println("Promote Options:");
					System.out.println("[1] Rook " + whiteRook);
					System.out.println("[2] Knight " + whiteKnight);
					System.out.println("[3] Bishop "+ whiteBishop);
					System.out.println("[4] Queen " + whiteQueen);
					
					Scanner temp = new Scanner(System.in);
					
					promoteOption = temp.nextInt();
					temp.close();
					
					switch(promoteOption)
					{
					case 1:
						CURRENTBOARD[NextPosition[0]][NextPosition[1]]=whiteRook;
						break;
					case 2:
						CURRENTBOARD[NextPosition[0]][NextPosition[1]]=whiteKnight;
						break;
					case 3:
						CURRENTBOARD[NextPosition[0]][NextPosition[1]]=whiteBishop;
						break;
					case 4:
						CURRENTBOARD[NextPosition[0]][NextPosition[1]] = whiteQueen;
						break;
					}
				}while(promoteOption<1||promoteOption>4);
				
				
				return true;
			}
    	}
    	else
    	{
    		//black
    		//push forward 2:
    		
			if(CurrentPosition[0]==1&&NextPosition[0]==3 && unoccupied(CURRENTBOARD, NextPosition[0], NextPosition[1])&&CurrentPosition[1]==NextPosition[1])
			{
				//checks push of two from pawn start
				return true;
			}
			else if(NextPosition[0]==(CurrentPosition[0]+1)&&unoccupied(CURRENTBOARD, NextPosition[0], NextPosition[1])&&CurrentPosition[1]==NextPosition[1])
			{
				//single push onto empty square
				return true;
			}
			else if(NextPosition[0]==(CurrentPosition[0]+1)&&NextPosition[1]==(CurrentPosition[1]+1))
			{
				//for taking pieces
				return true;
			}
			else if(NextPosition[0]==(CurrentPosition[0]+1)&&NextPosition[1]==(CurrentPosition[1]-1))
			{
				//for taking pieces
				return true;
			}
			else if(NextPosition[0]==7)
			{
				do {
					System.out.println("Promote Options:");
					System.out.println("[1] Rook " + whiteRook);
					System.out.println("[2] Knight " + whiteKnight);
					System.out.println("[3] Bishop "+ whiteBishop);
					System.out.println("[4] Queen " + whiteQueen);
					
					Scanner temp = new Scanner(System.in);
					
					promoteOption = temp.nextInt();
					temp.close();
					
					switch(promoteOption)
					{
					case 1:
						CURRENTBOARD[NextPosition[0]][NextPosition[1]]=whiteRook;
						break;
					case 2:
						CURRENTBOARD[NextPosition[0]][NextPosition[1]]=whiteKnight;
						break;
					case 3:
						CURRENTBOARD[NextPosition[0]][NextPosition[1]]=whiteBishop;
						break;
					case 4:
						CURRENTBOARD[NextPosition[0]][NextPosition[1]] = whiteQueen;
						break;
					}
				}while(promoteOption<1||promoteOption>4);
				
				
				return true;
			}
    	}
    	
    	return false;
    }
    
    public static boolean bishopCheck(String CURRENTBOARD[][], int CurrentPosition[], int NextPosition[])
    {
    	boolean myBishopCheck = false;
    	int j;
    	
    	if(NextPosition[0]>CurrentPosition[0])//they move down(remember we're using array indexes) and:
    	{
    		j=1;
    		if(NextPosition[1]>CurrentPosition[1])//they move right
    		{
    			for(int x = (CurrentPosition[0]+1); x<=NextPosition[0]; x++)//checking from left->right
    			{
		    		if(unoccupied(CURRENTBOARD,x,(CurrentPosition[1]+j)))
					{
		    			myBishopCheck = true;
					}
		    		else
		    		{
		    			return false;
		    		}
		    		j++;
    			}	
    		}
    		else if(NextPosition[1]<CurrentPosition[1])//they move left
    		{
    			j=1;
    			for(int x = (CurrentPosition[0]-1); x>=NextPosition[0];x--)//checking from right->left
    			{
    				if(unoccupied(CURRENTBOARD, x, CurrentPosition[1]-j))
    				{
    					myBishopCheck=true;
    				}
    				else
    				{
    					return false;
    				}
    				j++;
    			}
    		}
	    	
    	}
    	else if(NextPosition[0]<CurrentPosition[0])//if they move up(remember we're using array indexes) and:
    	{
    		j=1;
    		if(NextPosition[1]>CurrentPosition[1])//they move right
    		{
    			for(int x = (CurrentPosition[0]+1); x<=NextPosition[0]; x++)
    			{
		    		if(unoccupied(CURRENTBOARD,x,(CurrentPosition[1]+j)))
					{
		    			myBishopCheck = true;
					}
		    		else
		    		{
		    			return false;
		    		}
		    		j++;
    			}	
    		}
    		else if(NextPosition[1]<CurrentPosition[1])//they move left
    		{
    			j=1;
    			for(int x = (CurrentPosition[0]-1); x>=NextPosition[0];x--)
    			{
    				if(unoccupied(CURRENTBOARD, x, CurrentPosition[1]-j))
    				{
    					myBishopCheck=true;
    				}
    				else
    				{
    					return false;
    				}
    				j++;
    			}
    		}
    	}
    	
    	
    	return myBishopCheck;
    }
    
    public static boolean queenCheck(String CURRENTBOARD[][], int CurrentPosition[], int NextPosition[])
    {
    	return true;
    }
    
    public static boolean rooksAvailableMoves(String CURRENTBOARD[][], int NextPosition[], int row, int column)
    {
    	for(int i = 0; i<8; i++)
    	{
    		if(unoccupied(CURRENTBOARD, i, column))
    		{
    			CURRENTBOARD[i][column] = "X";
    		}
    	}
    	
    	for(int j = 0; j<8; j++)
    	{
    		if(unoccupied(CURRENTBOARD, row, j))
    		{
    			CURRENTBOARD[row][j] = "X";
    		}
    	}
    	
    	if(CURRENTBOARD[NextPosition[0]][NextPosition[1]]=="X")
    	{
    		return false;
    	}
    	
    	return true;
    }
    
    public static boolean bishopsAvailableMoves(String CURRENTBOARD[][], int NextPosition[], int row, int column)
    {
    	boolean myBishopCheck = true;
    	
    	int j=column;
    	
    	//going right & up
    	for(int i = (row+1); i<8; i++)// the +1 ensures we don't replace the piece
    	{
    		j++;
    		if(unoccupied(CURRENTBOARD, i, j))
    		{
    			CURRENTBOARD[i][j]="X";
    		}
    	}
    	
    	j=column;
    	
    	//going right & down
    	for(int i = (row+1);i<8;i++)
    	{
    		j--;
    		if(unoccupied(CURRENTBOARD, i, j))
    		{
    			CURRENTBOARD[i][j]="X";
    		}
    	}
    	
    	j = column;
    	
    	//going left & down
    	for(int i = (row-1);i>=0;i--)
    	{
    		j--;
    		if(unoccupied(CURRENTBOARD, i , j))
    		{
    			CURRENTBOARD[i][j]="X";
    		}
    	}
    	
    	j=column;
    	
    	//going left & up
    	for(int i = (row-1);i>=0;i--)
    	{
    		j--;
    		if(unoccupied(CURRENTBOARD, i ,j))
    		{
    			CURRENTBOARD[i][j]="X";
    		}
    	}
    	
    	if(CURRENTBOARD[NextPosition[0]][NextPosition[1]]=="X")
    	{
    		return false;
    	}
    	
    	return myBishopCheck;
    }

    public static boolean knightsAvailableMoves(String CURRENTBOARD[][], int NextPosition[], int row, int column)
    {
    	boolean knightBool = false;
    	
    	try {
			//Two up, one left/right:
			if (unoccupied(CURRENTBOARD, row + 2, column + 1))
				CURRENTBOARD[row + 2][column + 1] = "X";
			if (unoccupied(CURRENTBOARD, row + 2, column - 1))
				CURRENTBOARD[row + 2][column - 1] = "X";
			//One up, Two left/right:
			if (unoccupied(CURRENTBOARD, row + 1, column + 2))
				CURRENTBOARD[row + 1][column + 2] = "X";
			if (unoccupied(CURRENTBOARD, row + 1, column - 2))
				CURRENTBOARD[row + 1][column - 2] = "X";
			//One down, Two left/right
			if (unoccupied(CURRENTBOARD, row - 1, column + 2))
				CURRENTBOARD[row - 1][column + 2] = "X";
			if (unoccupied(CURRENTBOARD, row - 1, column - 2))
				CURRENTBOARD[row - 1][column - 2] = "X";
			//Two down, one left/right
			if (unoccupied(CURRENTBOARD, row - 2, column + 1))
				CURRENTBOARD[row - 2][column + 1] = "X";
			if (unoccupied(CURRENTBOARD, row - 2, column - 1))
				CURRENTBOARD[row - 2][column - 1] = "X";
		}
    	catch(ArrayIndexOutOfBoundsException e)
    	{
			
		}
		if(CURRENTBOARD[NextPosition[0]][NextPosition[1]]=="X")
    		return false;
    	
    	
    	return knightBool;
    }
    
    public static boolean queensAvailableMoves(String CURRENTBOARD[][], int NextPosition[], int row, int column)
    {
    	
    	int j=column;
    	
    	//Bishop Moves Check:
    	
    	//going right & up
    	for(int i = (row+1); i<8; i++)// the +1 ensures we don't replace the piece
    	{
    		j++;
    		if(unoccupied(CURRENTBOARD, i, j))
    		{
    			CURRENTBOARD[i][j]="X";
    		}
    	}
    	
    	j=column;
    	
    	//going right & down
    	for(int i = (row+1);i<8;i++)
    	{
    		j--;
    		if(unoccupied(CURRENTBOARD, i, j))
    		{
    			CURRENTBOARD[i][j]="X";
    		}
    	}
    	
    	j = column;
    	
    	//going left & down
    	for(int i = (row-1);i>=0;i--)
    	{
    		j--;
    		if(unoccupied(CURRENTBOARD, i , j))
    		{
    			CURRENTBOARD[i][j]="X";
    		}
    	}
    	
    	j=column;
    	
    	//going left & up
    	for(int i = (row-1);i>=0;i--)
    	{
    		j--;
    		if(unoccupied(CURRENTBOARD, i ,j))
    		{
    			CURRENTBOARD[i][j]="X";
    		}
    	}
    	
    	//rook moves:
    	
    	for(int i = 0; i<8; i++)
    	{
    		if(unoccupied(CURRENTBOARD, i, column))
    		{
    			CURRENTBOARD[i][column] = "X";
    		}
    	}
    	
    	for(int k = 0; k<8; j++)
    	{
    		if(unoccupied(CURRENTBOARD, row, k))
    		{
    			CURRENTBOARD[row][k] = "X";
    		}
    	}
    	
    	if(CURRENTBOARD[NextPosition[0]][NextPosition[1]]=="X")
    	{
    		return false;
    	}
    	
    	return true;
    }
    
    public static boolean pawnsAvailableMoves(String CURRENTBOARD[][], int NextPosition[], int playerTurn, int i, int j)
    {
    	if(playerTurn%2!=0)//White's Turn
    	{
    		try
    		{
	    		CURRENTBOARD[i-1][j-1]="X";
	    		CURRENTBOARD[i-1][j+1]="X";
    		}
    		catch(ArrayIndexOutOfBoundsException e)
    		{
    			
    		}
    	}
    	else
    	{
    		try
    		{
	    		CURRENTBOARD[i+1][j-1]="X";
	    		CURRENTBOARD[i+1][j+1]="X";
    		}
    		catch(ArrayIndexOutOfBoundsException e)
    		{
    			
    		}
    	}
    	
    	if(CURRENTBOARD[NextPosition[0]][NextPosition[1]]=="X")
    	{
    		return false;
    	}
    	
    	return true;
    }
    
    public static boolean kingIllegalMoves(String CURRENTBOARD[][],int playerTurn, int NextPosition[])
    {
    	//this method will replace squares where the king can't move with X's
    	//by checking each of the opponents pieces and marking unoccupied
    	//spaces with an X
    	
    	if(playerTurn%2!=0)//white's turn
    	{
	    	for(int i = 0; i<8; i++)
	    	{
	    		for(int j = 0; j<8; j++)
	    		{
	    			if(CURRENTBOARD[i][j]==blackRook)
	    			{
	    				return rooksAvailableMoves(CURRENTBOARD, NextPosition, i, j);
	    			}
	    			else if(CURRENTBOARD[i][j]==blackBishop)
	    			{
	    				return bishopsAvailableMoves(CURRENTBOARD, NextPosition, i, j);
	    			}
	    			else if(CURRENTBOARD[i][j]==blackKnight)
	    			{
	    				return knightsAvailableMoves(CURRENTBOARD, NextPosition, i, j);
	    			}
	    			else if(CURRENTBOARD[i][j]==blackQueen)
	    			{
	    				return queensAvailableMoves(CURRENTBOARD, NextPosition, i , j);
	    			}
	    			else if(CURRENTBOARD[i][j]==blackPawn)
	    			{
	    				return pawnsAvailableMoves(CURRENTBOARD, NextPosition, playerTurn, i, j);
	    			}
	    			else
	    			{
	    				return true;
	    			}
	    		}
	    	}
    	}
    	else//black's turn
    	{
    		for(int i = 0; i<8; i++)
	    	{
	    		for(int j = 0; j<8; j++)
	    		{
	    			if(CURRENTBOARD[i][j]==whiteRook)
	    			{
	    				rooksAvailableMoves(CURRENTBOARD, NextPosition, i, j);
	    			}
	    			else if(CURRENTBOARD[i][j]==whiteBishop)
	    			{
	    				return bishopsAvailableMoves(CURRENTBOARD, NextPosition, i,j);
	    			}
	    			else if(CURRENTBOARD[i][j]==whiteKnight)
	    			{
	    				return knightsAvailableMoves(CURRENTBOARD,NextPosition, i ,j );
	    			}
	    			else if(CURRENTBOARD[i][j]==whiteQueen)
	    			{
	    				return queensAvailableMoves(CURRENTBOARD, NextPosition, i , j);
	    			}
	    			else if(CURRENTBOARD[i][j]==whitePawn)
	    			{
	    				return pawnsAvailableMoves(CURRENTBOARD, NextPosition, playerTurn, i, j);
	    			}
	    			else
	    			{
	    				return true;
	    			}
	    		}
	    	}
    	}
    	return true;
    }
    
    public static boolean kingCheck(String CURRENTBOARD[][], int CurrentPosition[], int NextPosition[], int playerTurn)
    {
    	boolean myKingCheck = false;
    	
    	//checking if king is on any edge.
    	//then checking if they moved by one
    	
    	//Else means that he is somewhere
    	//in the middle of the board:
    	
    	boolean illegalMoves = kingIllegalMoves(CURRENTBOARD, playerTurn, NextPosition);
    	
    	if(illegalMoves==false)
    	{
    		System.out.println("Illegal Square: Check Oponent's open files");
    		return false;
    	}
    	
    	if(unoccupied(CURRENTBOARD, NextPosition[0], NextPosition[1]))
    		
    	if(CurrentPosition[0]==0)//black side
    	{
    		if(NextPosition[0]==(CurrentPosition[0]-1))//king moved up the board. (only possible option)
    		{
    			//check to see if they went left||right
	    			if(NextPosition[1]>=0&&NextPosition[1]<=7)//this one checks if they are in proper columns
	    			{
	    				//checks if they moved by one:
	    				if(NextPosition[1]==(CurrentPosition[1]+1))//checks if they moved right
	    					return true;
	    				if(NextPosition[1]==(CurrentPosition[1]-1))//left
	    					return true;
	    				if(NextPosition[1]==CurrentPosition[1])// or just up
	    					return true;
	    			}
    				System.out.println("The King Can't Move there.");
    		}
    	}
    	else if(CurrentPosition[0]==7)//white side
    	{
    		if(NextPosition[0]==(CurrentPosition[0]+1))//king moved down the board (only possible option)
    		{
    			//check to see if they went left||right
	    			if(NextPosition[1]>=0&&NextPosition[1]<=7)//this one checks if they are in proper columns
	    			{
	    				//checks if they moved by one:
	    				if(NextPosition[1]==(CurrentPosition[1]+1))//checks if they moved right
	    					return true;
	    				if(NextPosition[1]==(CurrentPosition[1]-1))//left
	    					return true;
	    				if(NextPosition[1]==CurrentPosition[1])// or just down
	    					return true;
	    			}
	    			System.out.println("The King Can't Move there.");
    		}
    	}
    	else if(CurrentPosition[1]==0)//left edge
    	{
    		if(NextPosition[1]==(CurrentPosition[1]+1))//King Moved to the right (only possible option)
    		{
    			//checks if they went up||down, by one
    			if(NextPosition[0]==(CurrentPosition[0]+1))//checks if they went up
    				return true;
    			if(NextPosition[0]==(CurrentPosition[0]-1))//down
    				return true;
    			if(NextPosition[0]==CurrentPosition[0])//or just right
    				return true;
    		}
    		System.out.println("The King Can't Move there.");
    	}
    	else if(CurrentPosition[1]==7)//right edge
    	{
    		if(NextPosition[1]==(CurrentPosition[1]-1))//King moved to the left (only possible option)
    		{
    			//checks if they went up||down, by one
    			if(NextPosition[0]==(CurrentPosition[0]+1))
    				return true;
    			if(NextPosition[0]==(CurrentPosition[0]-1))
    				return true;
    			if(NextPosition[0]==CurrentPosition[0])
    				return true;
    		}
    		System.out.println("The King Can't Move there.");
    	}
    	else {
    		if((NextPosition[0]==(CurrentPosition[0]+1))||(NextPosition[0]==(CurrentPosition[0]-1)))
    			if((NextPosition[1]==(CurrentPosition[1]+1))==(NextPosition[1]==(CurrentPosition[1]-1)))
    				return true;
    	}
    	
    	if(playerTurn%2!=0)//Castleling: if white:
	    	if((CurrentPosition[1]+2)==NextPosition[1]&&unoccupied(CURRENTBOARD, NextPosition[0],NextPosition[1])&&unoccupied(CURRENTBOARD,NextPosition[0],NextPosition[1]-1))
	    	{
	    		CURRENTBOARD[CurrentPosition[0]][CurrentPosition[1]] = "X";
	    		CURRENTBOARD[7][7] = "X";
	    		CURRENTBOARD[NextPosition[0]][NextPosition[1]] = whiteKing;
	    		CURRENTBOARD[NextPosition[0]][NextPosition[1]-1] = whiteRook;
	    		return true;
	    	}
	    	else if((CurrentPosition[1]-2)==NextPosition[1]&&unoccupied(CURRENTBOARD, NextPosition[0],NextPosition[1])&&unoccupied(CURRENTBOARD,NextPosition[0],NextPosition[1]+1))
	    	{
	    		CURRENTBOARD[CurrentPosition[0]][CurrentPosition[1]] = "X";
	    		CURRENTBOARD[7][0] = "X";
	    		CURRENTBOARD[NextPosition[0]][NextPosition[1]] = whiteKing;
	    		CURRENTBOARD[NextPosition[0]][NextPosition[1]-1] = whiteRook;
	    		return true;
	    	}
    	
    	if(playerTurn%2==0)//Castleling: if black:
    		if((CurrentPosition[1]+2)==NextPosition[1]&&unoccupied(CURRENTBOARD, NextPosition[0],NextPosition[1])&&unoccupied(CURRENTBOARD,NextPosition[0],NextPosition[1]-1))
        	{
        		CURRENTBOARD[CurrentPosition[0]][CurrentPosition[1]] = "X";
        		CURRENTBOARD[0][7] = "X";
        		CURRENTBOARD[NextPosition[0]][NextPosition[1]] = whiteKing;
        		CURRENTBOARD[NextPosition[0]][NextPosition[1]-1] = whiteRook;
        		return true;
        	}
        	else if((CurrentPosition[1]-2)==NextPosition[1]&&unoccupied(CURRENTBOARD, NextPosition[0],NextPosition[1])&&unoccupied(CURRENTBOARD,NextPosition[0],NextPosition[1]+1))
        	{
        		CURRENTBOARD[CurrentPosition[0]][CurrentPosition[1]] = "X";
        		CURRENTBOARD[0][0] = "X";
        		CURRENTBOARD[NextPosition[0]][NextPosition[1]] = whiteKing;
        		CURRENTBOARD[NextPosition[0]][NextPosition[1]-1] = whiteRook;
        		return true;
        	}
    	
    	return myKingCheck;
    }
    
    
    public static boolean ValidMoves(int playerTurn,int CurrentPosition[],int NextPosition[],String CURRENTBOARD[][],String playerName, String playerTwo, String History[][])
    {
    	//Check what piece will move and where.
    	//Also check what rows, columns,
    	//or diagonals it opens for pieces.
    	//discovered checks etc.\
    	//inside each case create call a new method for each piece
    	//to check whether that piece can move in the way they chose
    	//the next position
    	
    	
    	if(playerTurn%2!=0)
    	{
	    	switch(CURRENTBOARD[CurrentPosition[0]][CurrentPosition[1]])
	        {
	            case whiteRook:
	            {
	                //Checking if white rook
	            	return rookCheck(CURRENTBOARD, CurrentPosition, NextPosition);
	            }
	            case whiteKnight:
	            {
	                //checking if white knight (N)
	            	return knightCheck(CURRENTBOARD, CurrentPosition, NextPosition);
	            }
	            case whiteBishop:
	            {
	                //checking if white bishop
	            	return bishopCheck(CURRENTBOARD, CurrentPosition, NextPosition);
	            }
	            case whiteQueen:
	            {
	                //checking if white queen
	            	return queenCheck(CURRENTBOARD, CurrentPosition, NextPosition);
	            }
	            case whiteKing:
	            {
	                //checking if white king
	            	return kingCheck(CURRENTBOARD, CurrentPosition, NextPosition, playerTurn);
	            }
	            case whitePawn:
	            {
	                //checking if white pawn
	            	return pawnCheck(CURRENTBOARD, CurrentPosition, NextPosition, playerTurn, History);
	            }
	            default:
	            {
	            	return false;
	            }
            }
    	}
    	else
    	{
    		switch(CURRENTBOARD[CurrentPosition[0]][CurrentPosition[1]])
            {
                case blackRook:
                {
                    //Checking if black rook
                	return rookCheck(CURRENTBOARD, CurrentPosition, NextPosition);
                }
                case blackKnight:
                {
                    //checking if black knight
                    return knightCheck(CURRENTBOARD, CurrentPosition, NextPosition);
                }
                case blackBishop:
                {
                    //checking if black bishop
                    return bishopCheck(CURRENTBOARD, CurrentPosition, NextPosition);
                }
                case blackQueen:
                {
                    //checking if black queen
                	return queenCheck(CURRENTBOARD, CurrentPosition, NextPosition);
                }
                case blackKing:
                {
                    //checking if black king
                	return kingCheck(CURRENTBOARD, CurrentPosition, NextPosition, playerTurn);
                }
                case blackPawn:
                {
                    //checking if black pawn
                	return pawnCheck(CURRENTBOARD, CurrentPosition, NextPosition, playerTurn, History);
                }
                default:
                {
                	return false;
                }
            }
    	}
    }
    
    //needs work:
    
    public boolean validSelectionAndMove(int playerTurn, String CurrentPosition, String NextPosition, String CURRENTBOARD[][], String RECORDEDMOVES[], String playerName, String playerTwo, String History[][])
    {
    	int CurrentPosition_DecodedNotation[]=new int[2];
    	
        CurrentPosition_DecodedNotation[0] = DecodeRow(CurrentPosition);
        CurrentPosition_DecodedNotation[1] = DecodeColumn(CurrentPosition);
        
        int NextPosition_DecodedNotation[] = new int[2];
        
        NextPosition_DecodedNotation[0] = DecodeRow(NextPosition);
        NextPosition_DecodedNotation[1] = DecodeColumn(NextPosition);
        
        
        int newRow = NextPosition_DecodedNotation[0], newCol = NextPosition_DecodedNotation[1];
        int oldRow = CurrentPosition_DecodedNotation[0], oldCol=CurrentPosition_DecodedNotation[1];

        if(checkIfPlayerChoseTheirOwnPiece(playerTurn, CurrentPosition_DecodedNotation, CURRENTBOARD, playerName, playerTwo) && ValidMoves(playerTurn, CurrentPosition_DecodedNotation, NextPosition_DecodedNotation, CURRENTBOARD, playerName, playerTwo, History))
        {
            CURRENTBOARD[newRow][newCol]=CURRENTBOARD[oldRow][oldCol];
            CURRENTBOARD[oldRow][oldCol]="X";//replace with corresponding b/w square inside of print method

            return false;
            //when false, player did chose their own piece. Stops the
            //do-while loop in Main to increment player turn
        }
        System.out.println(ANSI_RED+"[ENTER VALID MOVE]"+ANSI_DEFAULT);
        return true;
    }

    public static boolean unoccupied(String CURRENTBOARD[][], int i, int j)
    {

        boolean unoccupied = true;

        //****need to have a switch to check all possible things inside of the array***//
        //which should only be pieces because squares get filled in later
        
        switch(CURRENTBOARD[i][j])
        {
            case blackRook:
            unoccupied = false;
            break;

            case blackKnight:
            unoccupied = false;
            break;

            case blackBishop:
            unoccupied = false;
            break;

            case blackKing:
            unoccupied = false;
            break;

            case blackQueen:
            unoccupied = false;
            break;

            case blackPawn:
            unoccupied = false;
            break;

            case whiteRook:
            unoccupied = false;
            break;

            case whiteKnight:
            unoccupied = false;
            break;

            case whiteBishop:
            unoccupied = false;
            break;

            case whiteKing:
            unoccupied = false;
            break;

            case whiteQueen:
            unoccupied = false;
            break;

            case whitePawn:
            unoccupied = false;
            break;

            case whiteSquare:
            unoccupied = true;
            break;

            case blackSquare:
            unoccupied = true;
            break;

            case "X":
            //this case is from when a player moves (validSelectionAndMove)
            //the last move erases and replaces with an X
            //in the array. Then it will be replaced with
            //it's corresponding b/w square.
            unoccupied = true;
            break;
        }
            
        return unoccupied;
    }

    
    public void printPlayerBoard(String CURRENTBOARD[][], int playerTurn)
    {
    	
        //String blackSquare = "\u2B1B", whiteSquare = "\u001B[97m\u2B1B\u001B[38;5;214m";

        //this will print the white side of the board
        if(playerTurn%2!=0)
        {
            for(int i = 0; i<=7; i++)
            {
                for(int j = 0; j<=7;j++)
                {

                    //need to fix piece checking
                    //If it is an empty square:
                    //if odd row
                    if(i%2!=0)
                    {
                        //and if odd column
                        if(j%2!=0)
                        {
                            //whiteSquare
                            if(unoccupied(CURRENTBOARD, i, j)){
                                CURRENTBOARD[i][j] = whiteSquare;
                            }
                        }
                        else
                        {
                            //if odd row and even column
                            if(unoccupied(CURRENTBOARD, i, j)){
                                CURRENTBOARD[i][j] = blackSquare;
                            }
                        }
                    }
                    else if(i%2==0)
                    {
                        //if even row
                        //if odd column
                        if(j%2!=0)
                        {
                            if(unoccupied(CURRENTBOARD, i, j)){
                                CURRENTBOARD[i][j] = blackSquare;
                            }
                        }
                        else
                        {
                            if(unoccupied(CURRENTBOARD, i, j)){
                                CURRENTBOARD[i][j] = whiteSquare;
                            }
                        }
                    }
                }
            }
            //White POV:
            //this prints board that was just arranged inside of the array:
            System.out.println("\n\t\t\t-------------------------");
            for(int i = 0; i<8; i++)
            {
            	System.out.print("\t\t\t"+(8-i)+" ");
                
                for(int j =0; j<8; j++)
                {
                	if(unoccupied(CURRENTBOARD,i,j))
        			{
                		System.out.printf("%s ",CURRENTBOARD[i][j]);
                		if(j==1||j==3)//this is aesthetic spacing
                		{
                			System.out.print(" ");
                		}
        			}
                	else {
                		System.out.printf("%s| ", CURRENTBOARD[i][j]);
                	}
                }
                System.out.println();
            }
            System.out.println("\t\t\t-------------------------");
            System.out.println("\t\t\t  a  b  c  d  e  f  g  h");
        }
        else if(playerTurn%2==0)
        {
        	for(int i = 0; i<=7; i++)
            {
        		
                for(int j = 0; j<=7;j++)
                {

                    //need to fix piece checking
                    //If it is an empty square:
                    //if odd row
                    if(i%2!=0)
                    {
                        //and if odd column
                        if(j%2!=0)
                        {
                            //whiteSquare
                            if(unoccupied(CURRENTBOARD, i, j)){
                                CURRENTBOARD[i][j] = whiteSquare;
                            }
                        }
                        else
                        {
                            //if odd row and even column
                            if(unoccupied(CURRENTBOARD, i, j)){
                                CURRENTBOARD[i][j] = blackSquare;
                            }
                        }
                    }
                    else if(i%2==0)
                    {
                        //if even row
                        //if odd column
                        if(j%2!=0)
                        {
                            if(unoccupied(CURRENTBOARD, i, j)){
                                CURRENTBOARD[i][j] = blackSquare;
                            }
                        }
                        else
                        {
                            if(unoccupied(CURRENTBOARD, i, j)){
                                CURRENTBOARD[i][j] = whiteSquare;
                            }
                        }
                    }
                }
            }
            //Black's POV:
            //this prints board that was just arranged inside of the array:
            System.out.println("\n\t\t\t-------------------------");
            for(int i = 7; i>=0; i--)
            {
                System.out.print("\t\t\t"+(8-i)+" ");
                
                for(int j =7; j>=0; j--)
                {
                	if(unoccupied(CURRENTBOARD,i,j))
        			{
                		System.out.printf("%s ",CURRENTBOARD[i][j]);
                		if(j==1||j==3)//aesthetic spacing
                		{
                			System.out.print(" ");
                		}
        			}
                	else {
                		System.out.printf("%s| ", CURRENTBOARD[i][j]);
                	}
                }
                System.out.println();
            }
            System.out.println("\t\t\t-------------------------");
            System.out.println("\t\t\t  h  g  f  e  d  c  b  a");
        }
    }
}