package hangman;
import java.util.Scanner;

public class Main {
	//kev's strings: just ignore
	final static String blackRook = "\033[30m\u2656\033[31;33m", blackKnight ="\033[30m\u2658\033[31;33m", blackBishop = "\033[30m\u2657\033[31;33m";
    final static String blackQueen = "\033[30m\u2655\033[31;33m", blackKing = "\033[30m\u2654\033[31;33m", blackPawn="\033[30m\u2659\033[31;33m";

    final static String whiteRook = "\033[37m\u2656\033[31;33m", whiteKnight = "\033[37m\u2658\033[31;33m", whiteBishop = "\033[37m\u2657\033[31;33m";
    final static String whiteQueen = "\033[37m\u2655\033[31;33m", whiteKing ="\033[37m\u2654\033[31;33m", whitePawn = "\033[37m\u2659\033[31;33m";
    
    final static String blackSquare = "\033[30m\u2B1B", whiteSquare = "\033[97m\u2B1B\u001B[38;5;214m";
	
    final static String ANSI_BLUE = "\033[34m";
	final static String ANSI_DEFAULT = "\033[38;5;214m", ANSI_GOLD = "\033[38;5;214m";
	final static String ANSI_GREEN = "\033[32m";
	final static String ANSI_RED = "\033[31m";

	public static void main(String[] args) {
		byte userSelect;
		boolean isChoice = false;
		Scanner in = new Scanner(System.in);
		
		while (!isChoice) {
			//lists mini-game options for player and allows them to exit
			System.out.println("Welcome to Byte Blitz!");
			System.out.println("Please select a minigame from the options below.");
			System.out.println("[1] Chess");
			System.out.println("[2] What Movie Should I Watch?");
			System.out.println("[3] Uno");
			System.out.println("[4] Guess the Number");
			System.out.println("[5] Hangman");
			System.out.println("[6] Exit");
			
			//prevents exception errors from being thrown, allows user to select again
			//if incorrect selection was entered
			try {
				userSelect = in.nextByte();
			}
			catch (Exception e) {
				System.out.println("Please select a valid option.\n");
				in.next();
				continue;
			}
			
			//tests that user input is recognized
			switch (userSelect) {
				case 1: {
					runBitBlitzYay();
					isChoice = true;
					break;
				}
				case 2: {
					MovieAssessment movieAssessment = new MovieAssessment();
					movieAssessment.movieGame();
					isChoice = true;
					break;
				}
				case 3: {
					System.out.println("The user selected Uno.");
					UnoGame uno = new UnoGame();
					uno.play();
					isChoice = true;
					break;
				}
				case 4: {
					System.out.println("The user selected number guessing.");
					NumberGuesser numberGame = new NumberGuesser();
					numberGame.guessTheNumber();
					isChoice = true;
					break;
				}
				case 5: {
					boolean isCorrectDifficulty = false;
					int difficulty = 0;
					while (!isCorrectDifficulty) {
						System.out.println("Please select a difficulty:");
						System.out.println("[1] Easy");
						System.out.println("[2] Medium");
						System.out.println("[3] Hard");
						difficulty = in.nextInt();
						in.nextLine();
						
						switch (difficulty) {
						case 1 ->{
							isCorrectDifficulty = true;
						}
						
						case 2 ->{
							isCorrectDifficulty = true;
						}
						
						case 3 ->{
							isCorrectDifficulty = true;
						}
						
						default ->{
							System.out.println("Please select a valid difficulty.");
						}
						}
					}
					
					Hangman hangman = new Hangman(difficulty);
					hangman.selectWord();
					hangman.drawHangmanBoard();
					
					first:
					while (hangman.wrongCounter != 6) {
						System.out.println("Guess a letter.");
						System.out.println("If you're confident, you can guess the entire word.");
						String guess = in.nextLine();
						boolean isGuess = hangman.checkGuess(guess);
						if (isGuess && guess.length() > 1) {
							System.out.println("Here are your points:");
							break first;
						}
						else if (isGuess){
							hangman.drawHangmanBoard();
							if (hangman.checkCurrentGuess()) {
								System.out.println("You've guessed the word!");
								break first;
							}
						}
						else {
							hangman.drawHangmanBoard();
						}
					}
					
					if (hangman.wrongCounter == 6) {
						hangman.drawHangmanBoard();
						System.out.println("You lose!");
					}
					isChoice = true;
				}
				case 6: {
					System.exit(0);
					break;
				}
				default: {
					System.out.println("Please select a valid option.\n");
				}
			}
		}
		
		in.close();
	}

	public static void runBitBlitzYay()
	{
		BitBlitz Chess = new BitBlitz();

        String RECORDEDMOVES[] = new String[100];

        String CURRENTBOARD[][] = {
            {blackRook, blackKnight, blackBishop, blackQueen, blackKing, blackBishop, blackKnight, blackRook},
            {blackPawn, blackPawn, blackPawn, blackPawn, blackPawn, blackPawn, blackPawn, blackPawn},
            {whiteSquare, blackSquare, whiteSquare, blackSquare, whiteSquare, blackSquare, whiteSquare, blackSquare},
            {blackSquare, whiteSquare, blackSquare, whiteSquare, blackSquare, whiteSquare, blackSquare, whiteSquare},
            {whiteSquare, blackSquare, whiteSquare, blackSquare, whiteSquare, blackSquare, whiteSquare, blackSquare},
            {blackSquare, whiteSquare, blackSquare, whiteSquare, blackSquare, whiteSquare, blackSquare, whiteSquare},
            {whitePawn, whitePawn, whitePawn, whitePawn, whitePawn, whitePawn, whitePawn, whitePawn},
            {whiteRook, whiteKnight, whiteBishop, whiteQueen, whiteKing, whiteBishop, whiteKnight, whiteRook}
            };
                
        Chess.printLogo();
        
        Chess.printWhiteBoard();
        

        String playerOne;
        String playerTwo;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("\n\t\t"+ANSI_BLUE+"Enter your name Player 1: "+ANSI_DEFAULT);
        playerOne = sc.next();
        
        System.out.print("\n\t\t"+ANSI_GREEN+"Enter your name Player 2: "+ANSI_DEFAULT);
        playerTwo = sc.next();
        
        System.out.println("\n\n\t\t"+ANSI_GOLD+"Welcome to BitBlitz: Chess "+ANSI_BLUE+ playerOne +ANSI_DEFAULT+ " and " +ANSI_RED+ playerTwo +ANSI_DEFAULT+ "!");


        int playerTurn = 0;//This will be used to choose which side of the board will be printed
                           //from there, you can see which player's turn it is

        String playerOneSide = Chess.chooseRandomSide();

        if(playerOneSide=="white")
        {
            playerOneSide = "white";
            System.out.println("\t\t"+ANSI_BLUE+playerOne+" "+ANSI_DEFAULT+whiteSquare+"\t"+ANSI_GREEN+playerTwo+" "+ANSI_DEFAULT+blackSquare);
        }
        else
        {
            playerOneSide = "black";

            System.out.println("\t\t"+ANSI_GREEN+playerTwo+" "+ANSI_DEFAULT+whiteSquare+"\t"+ANSI_BLUE+playerOne+" "+ANSI_DEFAULT+ blackSquare);
            System.out.println();
        }

        int actions = 0;//for menu selection
        char quitGame = 'o';//parameter of the do while

        // for first case in the menu
        String CurrentPosition = "a1", NextPosition = "a1";

        String Positions[] = new String[3];
        
        //Last 
        
        String History[][] = new String[100][2];
        
        
        int i =0, j=0;
        
        //Wrong_Redo1 and Wrong_Redo2 will be used to color the letters red
        //if the user enters an invalid current or next position

        boolean checkValidPiece = true;
        boolean validInput = false;
        do{
        	
            System.out.println(ANSI_GREEN+"\t\tMenu");
            System.out.println("\t\t1 : Move Piece");
            System.out.println("\t\t2 : Offer Draw");
            System.out.println("\t\t3 : Resign");
            System.out.println("\t\t4 : Quit Game");
            System.out.println("\t\t5: Declare CheckMate\n");

            System.out.print("\t\tYour Option: ");

            
            actions = sc.nextInt();
            validInput = true;
            
            System.out.print(ANSI_DEFAULT);        

            Chess.clearScreen();

            switch(actions)
            {

                case 1:
                {
                    //          Move Piece
					Chess.Tutorial(playerTurn);
					playerTurn+=1;//ensures alternation between players
                    
					do{
                        
                    	j=0;
                        Chess.printPlayerBoard(CURRENTBOARD, playerTurn);

                        //method to check whether user inputs strings of length 2, sc is my scanner
                        Positions = Chess.lengthTwoStrings(CurrentPosition, NextPosition, sc, playerOne, playerTwo, playerTurn);
                        
                        CurrentPosition=Positions[0];
                        NextPosition=Positions[1];
                        
                        checkValidPiece = Chess.validSelectionAndMove(playerTurn, CurrentPosition, NextPosition, CURRENTBOARD, RECORDEDMOVES, playerOne, playerTwo, History);
                        
                        if(checkValidPiece)
                        {
                        	History[i][j] = CurrentPosition;
		                    j++;
		                    History[i][j] = NextPosition;
		                    i++;
                        }
                    }
                    while(checkValidPiece);
                    break;
                }
                case 2:
                {
                    System.out.println("Offer Draw");
                    //playerTurn would like to draw, accept?
                    if(playerTurn%2!=0)
                    {
                    	System.out.println(playerOne+" Would Like to Draw. Do you Accept?[y/n]");
                    	quitGame = sc.next().charAt(0);
                    }
                    else
                    {
                    	System.out.println(playerTwo+" Would Like to Draw. Do you Accept?[y/n]");
                    	quitGame = sc.next().charAt(0);
                    }
                    break;
                }
                case 3:
                {
                    System.out.print("\n\n\t\t"+ANSI_RED+"Are you sure that you would like to resign? [y/n] "+ANSI_DEFAULT);
                    quitGame = sc.next().charAt(0);
                    System.out.print("\n\n\t\tPlay a new game?");
                    break;
                }
                case 4:
                {
                    System.out.print("\n\n\t\t"+ANSI_RED+"Are you sure that you would like to quit? [y/n] "+ANSI_DEFAULT);
                    quitGame = sc.next().charAt(0);
                    break;
                }
                case 5:
                {
                	if(playerTurn%2!=0)
                	{
                		System.out.println(playerOne+" Declared Checkmate on "+playerTwo);
                        System.out.println("Congratulations Player One!");
                	}
                	else
                	{
                		System.out.println(playerTwo + "Declared CheckMate on "+playerOne);
                        System.out.println("Congratulations Player Two!");
                	}
                	
                }
                default:
                {
                    System.out.println("\n\t\t"+ANSI_RED+"Please select a valid option"+ANSI_DEFAULT);
                    sc.nextLine();//clearing the scanner
                }
            }

        }
        while(quitGame!='y');
        //need to get out of this game to enter the shop
        sc.close();
        System.exit(0);
	}

}
